#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef enum{
	FRESH,
	OPEN,
	CLOSED
} t_status;

struct _list{
	int val;
	struct _list * next;
};
typedef struct _list list;

typedef struct{
	t_status status;
	int level;
	list * head;
	list * end;
} node;

int size;
node *nodes;

void addChild(int src, int dst)
{
	list * end = nodes[src].end;

	if (end == NULL) {
		end = (list *) calloc(1, sizeof(list));
		end->val = dst;
		nodes[src].head = nodes[src].end = end;
	} else {
		/*if (end->val == dst) return;*/
		end->next = (list *) calloc(1, sizeof(list));
		end->next->val = dst;
		nodes[src].end = end->next;
	}
}

void read()
{
	int /*i,*/ src, dst;

	nodes = (node*) malloc(size * sizeof(node));
	nodes = memset(nodes, 0, size);
	/*for (i = 0; i < size; ++i) {
		nodes[i].status = FRESH;
	}*/

	do {
		scanf("%d %d\n", &src, &dst);
		if (src == 0 && dst == 0) break;
		/*if (src == dst) continue;*/
		/*if (src >= size || dst >= size) continue;*/

		addChild(dst, src);
		addChild(src, dst);
	} while (1);
}

int DFS(int i, int parent, int level)
{
	int min_level = level, ret;
	list * cur;

	nodes[i].status = OPEN;
	nodes[i].level  = level;
	cur = nodes[i].head;

	while (cur != NULL) {
		if (cur->val != parent) {
			if (nodes[cur->val].status == FRESH) {
				ret = DFS(cur->val, i, level + 1);
				if (ret < min_level) min_level = ret;
				if (ret > level) {
					printf("%d %d\n", i, cur->val);
				}
			} else {
				if (nodes[cur->val].level < min_level) {
					min_level = nodes[cur->val].level;
				}
			}
		}
		cur = cur->next;
	}

	return min_level;
}

int main(int argc, char* argv[]) {
	scanf("%d\n", &size);

	read();
	DFS(0, 0, 0);
	printf("0 0\n");

	return 0;
}

#ifndef STACK
#define STACK

#include <stdlib.h>
#include <string.h>

struct stack_node {
	int v;
	struct stack_node* next;
};

struct stack {
	struct stack_node* head;
};

static inline void stack_node_init(struct stack_node * n)
{
	n->v = -1;
	n->next = NULL;
}

static inline void stack_init(struct stack * s){
	s->head = NULL; /*(struct stack_node *) malloc(sizeof(struct stack_node));
	stack_node_init(s->head);/*/
}

static inline void stack_push(struct stack * s, int v)
{
	struct stack_node * n;
	
	/*if (s->head->v == -1) {
		s->head->v = v;
		return;
	}*/
	n = (struct stack_node *) malloc(sizeof(struct stack_node));
	stack_node_init(n);
	n->next = s->head;
	n->v = v;
	s->head = n;
}

static inline int stack_pop(struct stack * s)
{
	int v;
	if (s->head == NULL) return -1;
	v = s->head->v;
	s->head = s->head->next;
	return v;
}

#endif /* STACK */
